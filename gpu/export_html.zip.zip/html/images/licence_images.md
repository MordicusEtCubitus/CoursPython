
# Licences des images
:label:`images`

**Nom**: CDC_6600_introduced_in_1964.jpg  
**Licence**: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)  
**Source**: https://en.wikipedia.org/wiki/History_of_supercomputing#/media/File:CDC_6600_introduced_in_1964.jpg

**Nom**: CDC_6600.jc.jpg  
**Licence**: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)  
**Source**: https://fr.wikipedia.org/wiki/Superordinateur#/media/File:CDC_6600.jc.jpg

**Nom**: IBM_Summit.jpg  
**Licence**: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)  
**Source**: https://en.wikipedia.org/wiki/Summit_(supercomputer)#/media/File:Summit_(supercomputer).jpg

**Nom**: top_500_os_family.png  
**Licence**: https://www.top500.org  
**Source**: https://www.top500.org/statistics/list/

**Nom**: top_500_os_shares.png  
**Licence**: https://www.top500.org   
**Source**: https://www.top500.org/statistics/list/

**Nom**: Products_Processors2.png  
**Licence**: https://www.kalray.eu  
**Source**: https://prod.kalray.eu/wp-content/uploads/2018/10/Products_Processors2.png

**Nom**: Dual_processor.jpg  
**Licence**: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)  
**Source**: https://fr.wikipedia.org/wiki/Multiprocesseur#/media/Fichier:Dual_processor.jpg

**Nom**: Tensor_Processing_Unit_3.0.jpg  
**Licence**: [ Creative Commons Attribution-Share Alike 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/deed.en)  
**Source**: https://en.wikipedia.org/wiki/File:Tensor_Processing_Unit_3.0.jpg

**Nom**: 800px-InfiniBand-CX4-Cable.jpg  
**Licence**: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)  
**Source**: https://fr.wikipedia.org/wiki/Bus_InfiniBand#/media/Fichier:InfiniBand-CX4-Cable.jpg

**Nom**:   bread-726528_640.jpg  
**Licence**: [Pixabay licence](https://pixabay.com/fr/service/license/)    
**Source**: https://pixabay.com/fr/photos/pain-boulangerie-boutique-cuit-726528/

**Nom**: Quad-Core AMD Opteron processor.jpg  
**Licence**: [AMD](https://www.amd.com)    
**Source**: https://fr.wikipedia.org/wiki/Microprocesseur_multi-c%C5%93ur#/media/Fichier:Quad-Core_AMD_Opteron_processor.jpg
        
> Le détenteur du droit d’auteur de ce fichier, Advanced Micro Devices, Inc. (AMD), autorise n’importe qui à l’utiliser pour n’importe quelle utilisation, pourvu que le détenteur du droit d’auteur soit correctement attribué. La redistribution, les œuvres dérivées, l’utilisation commerciale et toutes les autres utilisations sont autorisées.
Attribution: Advanced Micro Devices, Inc. (AMD)

**Nom**: Fpga1a.gif  
**Licence**: W.T.Freeman    
**Source**: https://commons.wikimedia.org/wiki/File:Fpga1a.gif



**Nom**: Asic.png  
**Licence**: [Creative Commons Attribution 3.0 Unported](https://creativecommons.org/licenses/by/3.0/deed.en)  
**Source**: https://commons.wikimedia.org/wiki/File:Asic.png




**Nom**: Blochsphere.svg.png   
**Licence**: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)  
**Source**: https://fr.wikipedia.org/wiki/Qubit#/media/Fichier:Blochsphere.svg






**Nom**: ../exercices/profiling/stopwatch.jpg  
**Licence**: [Pixabay](https://pixabay.com/service/license/)  
**Source**:  https://pixabay.com/illustrations/stopwatch-time-treadmill-race-259303/


**Nom**: ../exercices/profiling/superhero.jpg  
**Licence**: [Pixabay](https://pixabay.com/service/license/)  
**Source**:  https://pixabay.com/illustrations/superhero-girl-speed-runner-534120/





